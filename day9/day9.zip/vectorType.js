var person1 = {
    firstName:"Analy",
    lastName:"Joelly"
}
var person2 = {
    firstName:"Anala",
    lastName:"Joel"
}
